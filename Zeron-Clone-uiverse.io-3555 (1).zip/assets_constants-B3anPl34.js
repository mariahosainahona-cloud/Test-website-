import{B as o,P as i,C as a,S as r,F as s,b as n,I as l,d,f as c,g as p,Q as b,h as u,i as h,m as w,s as g,j as m,k as f,l as y,n as k,o as x}from"./icons-jhLKJmWx.js";const T={elements:{id:"elements",label:"All",path:"elements",title:"Browse all",altTitle:"UI elements",icon:o},buttons:{id:"button",label:"Buttons",path:"buttons",icon:i},checkboxes:{id:"checkbox",label:"Checkboxes",path:"checkboxes",icon:a},switches:{id:"switch",label:"Toggle switches",path:"switches",icon:r},cards:{id:"card",label:"Cards",path:"cards",icon:s},loaders:{id:"loader",label:"Loaders",path:"loaders",icon:n},inputs:{id:"input",label:"Inputs",path:"inputs",icon:l},"radio-buttons":{id:"radio",label:"Radio buttons",path:"radio-buttons",icon:d,new:!1},forms:{id:"form",label:"Forms",path:"forms",new:!1,icon:c},patterns:{id:"pattern",label:"Patterns",path:"patterns",icon:p},tooltips:{id:"tooltip",label:"Tooltips",path:"tooltips",new:!0,hideFromSidebar:!1,icon:b},favorites:{id:"favorites",label:"My favorites",path:"favorites",icon:u}},S={HTML:"HTML",CSS:"CSS"},I={theme:{id:"theme",items:[{label:"Any theme",id:"all",icon:h},{label:"Dark",id:"dark",icon:w},{label:"Light",id:"light",icon:g}]},orderBy:{id:"orderBy",icon:m,items:[{label:"Randomized",id:"randomized",icon:f},{label:"Favorites",id:"favorites",icon:y},{label:"Views",id:"views",icon:k},{label:"Recent",id:"recent",icon:x}]}},R={button:{css:`.button {
  cursor: pointer;
}`,html:`<button class="button">
  Button
</button>`,tailwind:`<button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">
  Button
</button>`},switch:{css:`/* The switch - the box around the slider */
.switch {
  font-size: 17px;
  position: relative;
  display: inline-block;
  width: 3.5em;
  height: 2em;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 30px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 1.4em;
  width: 1.4em;
  border-radius: 20px;
  left: 0.3em;
  bottom: 0.3em;
  background-color: white;
  transition: .4s;
}

.switch input:checked + .slider {
  background-color: #2196F3;
}

.switch input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

.switch input:checked + .slider:before {
  transform: translateX(1.5em);
}`,html:`<label class="switch">
  <input type="checkbox">
  <span class="slider"></span>
</label>`,tailwind:`<label class="relative inline-flex items-center cursor-pointer">
  <input type="checkbox" class="sr-only peer">
  <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
</label>`},checkbox:{css:`/* Hide the default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

.container {
  display: block;
  position: relative;
  cursor: pointer;
  font-size: 20px;
  user-select: none;
}

/* Create a custom checkbox */
.checkmark {
  position: relative;
  top: 0;
  left: 0;
  height: 1.3em;
  width: 1.3em;
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 0.45em;
  top: 0.25em;
  width: 0.25em;
  height: 0.5em;
  border: solid white;
  border-width: 0 0.15em 0.15em 0;
  transform: rotate(45deg);
}`,html:`<label class="container">
  <input type="checkbox" checked="checked">
  <div class="checkmark"></div>
</label>`,tailwind:`<label class="relative flex items-center cursor-pointer">
  <input type="checkbox" class="sr-only peer">
  <div class="w-5 h-5 bg-gray-200 rounded border border-gray-300 peer-checked:bg-blue-600 peer-checked:border-blue-600 transition-colors">
  </div>
  <span class="ml-2 text-sm font-medium text-gray-900">Checkbox</span>
</label>`},card:{html:'<div class="card"></div>',css:`.card {
  width: 190px;
  height: 254px;
  background: lightgrey;
}`,tailwind:`<div class="max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow">
  <div class="mb-2 text-2xl font-bold tracking-tight text-gray-900">Card title</div>
  <p class="mb-3 font-normal text-gray-700">Card content goes here.</p>
</div>`},loader:{html:'<div class="loader"></div>',css:`.loader {
  
}`,tailwind:`<div class="flex items-center justify-center">
  <div class="w-8 h-8 border-4 border-blue-200 rounded-full animate-spin border-t-blue-600"></div>
</div>`},input:{html:'<input type="text" name="text" class="input">',css:`.input {
  max-width: 190px;
}`,tailwind:'<input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 max-w-xs" placeholder="Input text">'},form:{html:`<form class="form">
    <input type="text" class="input">
    <input type="text" class="input"> 
    <button>Submit</button>
</form>`,css:`.form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.form button {
  align-self: flex-end;
}
    `,tailwind:`<form class="max-w-sm mx-auto space-y-4">
  <div>
    <label class="block mb-2 text-sm font-medium text-gray-900">Email</label>
    <input type="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="name@example.com">
  </div>
  <div>
    <label class="block mb-2 text-sm font-medium text-gray-900">Password</label>
    <input type="password" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
  </div>
  <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5">Submit</button>
</form>`},notification:{html:'<div class="notification"></div>',css:`.notification {
  width: 250px;
  height: 60px;
  background: lightgrey;
  border-radius: 14px;
}`,tailwind:`<div class="fixed bottom-4 right-4 p-4 text-sm text-white bg-blue-600 rounded-lg shadow-lg">
  <span>Notification message</span>
</div>`},radio:{html:`<div class="radio-input">
  <input type="radio" id="value-1" name="value-radio" value="value-1">
  <input type="radio" id="value-2" name="value-radio" value="value-2">
  <input type="radio" id="value-3" name="value-radio" value="value-3">
</div>`,css:`.radio-input input {

}`,tailwind:`<div class="space-y-2">
  <label class="relative flex items-center cursor-pointer">
    <input type="radio" name="radio" class="sr-only peer">
    <div class="w-5 h-5 bg-gray-200 rounded-full border border-gray-300 peer-checked:bg-blue-600 peer-checked:border-blue-600 transition-colors">
      <div class="absolute inset-0 flex items-center justify-center opacity-0 peer-checked:opacity-100">
        <div class="w-2 h-2 bg-white rounded-full"></div>
      </div>
    </div>
    <span class="ml-2 text-sm font-medium text-gray-900">Option 1</span>
  </label>
  <label class="relative flex items-center cursor-pointer">
    <input type="radio" name="radio" class="sr-only peer">
    <div class="w-5 h-5 bg-gray-200 rounded-full border border-gray-300 peer-checked:bg-blue-600 peer-checked:border-blue-600 transition-colors">
      <div class="absolute inset-0 flex items-center justify-center opacity-0 peer-checked:opacity-100">
        <div class="w-2 h-2 bg-white rounded-full"></div>
      </div>
    </div>
    <span class="ml-2 text-sm font-medium text-gray-900">Option 2</span>
  </label>
</div>`},pattern:{html:'<div class="container"></div>',css:`.container {
  width: 100%;
  height: 100%;
  /* Add your background pattern here */
  background: lightblue;
}`,tailwind:'<div class="w-full h-64 bg-gradient-to-r from-blue-500 to-purple-500"></div>'},tooltip:{html:`<div class="tooltip-container">
  <span class="tooltip">Uiverse.io</span>
  <span class="text">Tooltip</span>
</div>`,css:`/* This is an example, feel free to delete this code */
.tooltip-container {
  --background: #22d3ee;
  position: relative;
  background: var(--background);
  cursor: pointer;
  transition: all 0.2s;
  font-size: 17px;
  padding: 0.7em 1.8em;
}

.tooltip {
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  padding: 0.3em 0.6em;
  opacity: 0;
  pointer-events: none;
  transition: all 0.3s;
  background: var(--background);
}

.tooltip::before {
  position: absolute;
  content: "";
  height: 0.6em;
  width: 0.6em;
  bottom: -0.2em;
  left: 50%;
  transform: translate(-50%) rotate(45deg);
  background: var(--background);
}

.tooltip-container:hover .tooltip {
  top: -100%;
  opacity: 1;
  visibility: visible;
  pointer-events: auto;
}`,tailwind:`<div class="group relative">
  <button class="px-4 py-2 bg-blue-500 text-white rounded">Hover me</button>
  <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 text-sm text-white bg-gray-900 rounded opacity-0 group-hover:opacity-100 transition-opacity">
    Tooltip text
  </div>
</div>`},footer:{html:'<div class="footer"></div>',css:`.footer {
  width: 100%;
  height: 100%;
  background: lightgrey;
}`,tailwind:`<footer class="bg-gray-800 text-white py-4">
  <div class="container mx-auto px-4">
    <p>&copy; 2024 Your Company. All rights reserved.</p>
  </div>
</footer>`},sidebar:{html:'<div class="sidebar"></div>',css:`.sidebar {
  width: 100%;
  height: 100%;
  background: lightgrey;
}`,tailwind:`<div class="w-64 bg-gray-800 text-white">
  <div class="p-4">
    <h3 class="text-lg font-semibold">Sidebar</h3>
  </div>
</div>`},pagination:{html:'<div class="pagination"></div>',css:`.pagination {
  width: 100%;
  height: 100%;
  background: lightgrey;
}`,tailwind:`<div class="flex justify-center items-center h-screen">
  <div class="flex space-x-4">
    <button class="px-4 py-2 bg-blue-500 text-white rounded">Previous</button>
    <button class="px-4 py-2 bg-blue-500 text-white rounded">Next</button>
  </div>
</div>`}},E=`* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
button {
  font-family: inherit;
}

`,O=(t=[])=>`${t.map(e=>`Copyright - ${new Date().getFullYear()} ${e} 
`).join("")}
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

`,N=`
/* ! tailwindcss v3.3.2 | MIT License | https://tailwindcss.com */*,::after,::before {
  box-sizing: border-box;
  border-width: 0;
  border-style: solid;
  border-color: #e5e7eb
}

::after,::before {
  --tw-content: ''
}

html {
  line-height: 1.5;
  -webkit-text-size-adjust: 100%;
  -moz-tab-size: 4;
  tab-size: 4;
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  font-feature-settings: normal;
  font-variation-settings: normal
}

body {
  margin: 0;
  line-height: inherit
}

hr {
  height: 0;
  color: inherit;
  border-top-width: 1px
}

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted
}

h1,h2,h3,h4,h5,h6 {
  font-size: inherit;
  font-weight: inherit
}

a {
  color: inherit;
  text-decoration: inherit
}

b,strong {
  font-weight: bolder
}

code,kbd,pre,samp {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 1em
}

small {
  font-size: 80%
}

sub,sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline
}

sub {
  bottom: -.25em
}

sup {
  top: -.5em
}

table {
  text-indent: 0;
  border-color: inherit;
  border-collapse: collapse
}

button,input,optgroup,select,textarea {
  font-family: inherit;
  font-size: 100%;
  font-weight: inherit;
  line-height: inherit;
  color: inherit;
  margin: 0;
  padding: 0
}

button,select {
  text-transform: none
}

[type=button],[type=reset],[type=submit],button {
  -webkit-appearance: button;
  background-color: transparent;
  background-image: none
}

:-moz-focusring {
  outline: auto
}

:-moz-ui-invalid {
  box-shadow: none
}

progress {
  vertical-align: baseline
}

::-webkit-inner-spin-button,::-webkit-outer-spin-button {
  height: auto
}

[type=search] {
  -webkit-appearance: textfield;
  outline-offset: -2px
}

::-webkit-search-decoration {
  -webkit-appearance: none
}

::-webkit-file-upload-button {
  -webkit-appearance: button;
  font: inherit
}

summary {
  display: list-item
}

blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre {
  margin: 0
}

fieldset {
  margin: 0;
  padding: 0
}

legend {
  padding: 0
}

menu,ol,ul {
  list-style: none;
  margin: 0;
  padding: 0
}

textarea {
  resize: vertical
}

input::placeholder,textarea::placeholder {
  opacity: 1;
  color: #9ca3af
}

[role=button],button {
  cursor: pointer
}

:disabled {
  cursor: default
}

audio,canvas,embed,iframe,img,object,svg,video {
  display: block;
  vertical-align: middle
}

img,video {
  max-width: 100%;
  height: auto
}

[hidden] {
  display: none
}

*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x: ;--tw-pan-y:;
  --tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;
  --tw-gradient-from-position: ;--tw-gradient-via-position:;
  --tw-gradient-to-position: ;--tw-ordinal:;
  --tw-slashed-zero: ;--tw-numeric-figure:;
  --tw-numeric-spacing: ;--tw-numeric-fraction:;
  --tw-ring-inset: ;--tw-ring-offset-width:0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur: ;--tw-brightness:;
  --tw-contrast: ;--tw-grayscale:;
  --tw-hue-rotate: ;--tw-invert:;
  --tw-saturate: ;--tw-sepia:;
  --tw-drop-shadow: ;--tw-backdrop-blur:;
  --tw-backdrop-brightness: ;--tw-backdrop-contrast:;
  --tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate:;
  --tw-backdrop-invert: ;--tw-backdrop-opacity:;
  --tw-backdrop-saturate: ;--tw-backdrop-sepia:
}

::-webkit-backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x: ;--tw-pan-y:;
  --tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;
  --tw-gradient-from-position: ;--tw-gradient-via-position:;
  --tw-gradient-to-position: ;--tw-ordinal:;
  --tw-slashed-zero: ;--tw-numeric-figure:;
  --tw-numeric-spacing: ;--tw-numeric-fraction:;
  --tw-ring-inset: ;--tw-ring-offset-width:0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur: ;--tw-brightness:;
  --tw-contrast: ;--tw-grayscale:;
  --tw-hue-rotate: ;--tw-invert:;
  --tw-saturate: ;--tw-sepia:;
  --tw-drop-shadow: ;--tw-backdrop-blur:;
  --tw-backdrop-brightness: ;--tw-backdrop-contrast:;
  --tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate:;
  --tw-backdrop-invert: ;--tw-backdrop-opacity:;
  --tw-backdrop-saturate: ;--tw-backdrop-sepia:
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x: ;--tw-pan-y:;
  --tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;
  --tw-gradient-from-position: ;--tw-gradient-via-position:;
  --tw-gradient-to-position: ;--tw-ordinal:;
  --tw-slashed-zero: ;--tw-numeric-figure:;
  --tw-numeric-spacing: ;--tw-numeric-fraction:;
  --tw-ring-inset: ;--tw-ring-offset-width:0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur: ;--tw-brightness:;
  --tw-contrast: ;--tw-grayscale:;
  --tw-hue-rotate: ;--tw-invert:;
  --tw-saturate: ;--tw-sepia:;
  --tw-drop-shadow: ;--tw-backdrop-blur:;
  --tw-backdrop-brightness: ;--tw-backdrop-contrast:;
  --tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate:;
  --tw-backdrop-invert: ;--tw-backdrop-opacity:;
  --tw-backdrop-saturate: ;--tw-backdrop-sepia:
}`;export{I as D,S as L,T as a,R as d,E as g,O as m,N as t};
